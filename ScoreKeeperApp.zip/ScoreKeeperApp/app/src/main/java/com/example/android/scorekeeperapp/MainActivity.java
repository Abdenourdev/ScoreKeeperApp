package com.example.android.scorekeeperapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.android.scorekeeperapp.R;

public class MainActivity extends AppCompatActivity {
    int scoreFcBarcelona=0;
    int scoreRealMadrid =0;
    int scoreFcBarcelonashots =0;
    int scoreFcBarcelonapossession = 0;
    int scoreFcBarcelonacorner_kick =0;
    int scoreRealMadridshots;
    int scoreRealMadridpossession =0;
    int scoreRealMadridcorner =0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        displayForFcBarcelona(0);
        displayForRealMadrid(0);

    }

    public void displayForFcBarcelona(int score) {
        TextView scoreView = (TextView) findViewById(R.id.fc_barcalona);
        scoreView.setText(String.valueOf(score));
    }
    public void addOneForFcBarcelona(View view){
        scoreFcBarcelona=scoreFcBarcelona+1;
        displayForFcBarcelona(scoreFcBarcelona);
    }


    public void displayForRealMadrid(int score) {
        TextView scoreView = (TextView) findViewById(R.id.r_madrid);
        scoreView.setText(String.valueOf(score));
    }
    public void addOneForRealMadrid(View view){
        scoreRealMadrid=scoreRealMadrid+1;
        displayForRealMadrid(scoreRealMadrid);
    }
    public void displayForFcBarcelonashots(int score) {
        TextView scoreView = (TextView) findViewById(R.id.z1);
        scoreView.setText(String.valueOf(score));
    }
    public void addOneForFcBarcelonashots(View view){
        scoreFcBarcelonashots = scoreFcBarcelonashots +1;
        displayForFcBarcelonashots(scoreFcBarcelonashots);
    }

    public void displayForFcBarcelonapossession(int score) {
        TextView scoreView = (TextView) findViewById(R.id.z3);
        scoreView.setText(String.valueOf(score));
    }
    public void addOneForFcBarcelonapossession(View view){
        scoreFcBarcelonapossession = scoreFcBarcelonapossession +1;
        displayForFcBarcelonapossession(scoreFcBarcelonapossession);
    }
    public void displayForFcBarcelonacorner_kick(int score) {
        TextView scoreView = (TextView) findViewById(R.id.z5);
        scoreView.setText(String.valueOf(score));
    }
    public void addOneForFcBarcelonacorner(View view){
        scoreFcBarcelonacorner_kick = scoreFcBarcelonacorner_kick +1;
        displayForFcBarcelonacorner_kick(scoreFcBarcelonacorner_kick);
    }
    public void displayForRealMadridshots(int score) {
        TextView scoreView = (TextView) findViewById(R.id.z);
        scoreView.setText(String.valueOf(score));
    }
    public void addOneForRealMadridshots(View view){
        scoreRealMadridshots = scoreRealMadridshots +1;
        displayForRealMadridshots(scoreRealMadridshots);
    }
    public void displayForRealMadridpossession(int score) {
        TextView scoreView = (TextView) findViewById(R.id.z2);
        scoreView.setText(String.valueOf(score));
    }
    public void addOneForRealMadridpossession(View view){
        scoreRealMadridpossession = scoreRealMadridpossession +1;
        displayForRealMadridpossession(scoreRealMadridpossession);
    }

    public void displayForRealMadridcorner(int score) {
        TextView scoreView = (TextView) findViewById(R.id.z4);
        scoreView.setText(String.valueOf(score));
    }
    public void addOneForRealMadridcorner(View view){
        scoreRealMadridcorner = scoreRealMadridcorner +1;
        displayForRealMadridcorner(scoreRealMadridcorner);
    }




    public void resetscore(View view){
         scoreFcBarcelona=0;
         scoreRealMadrid =0;
         scoreFcBarcelonashots =0;
         scoreFcBarcelonapossession = 0;
         scoreFcBarcelonacorner_kick =0;
         scoreRealMadridshots = 0;
         scoreRealMadridpossession = 0;
         scoreRealMadridcorner = 0;

        displayForFcBarcelona(scoreFcBarcelona);
        displayForRealMadrid(scoreRealMadrid);
        displayForFcBarcelonashots(scoreFcBarcelonashots);
        displayForFcBarcelonapossession(scoreFcBarcelonapossession);
        displayForFcBarcelonacorner_kick(scoreFcBarcelonacorner_kick);
        displayForRealMadridshots(scoreRealMadridshots);
        displayForRealMadridpossession(scoreRealMadridpossession);
        displayForRealMadridcorner(scoreRealMadridcorner);
    }
}